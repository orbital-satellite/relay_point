def entry(hyperparams):
	return hyperparams['arg'] ** 2

