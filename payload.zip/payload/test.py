def test_fn(*args, **kwargs):
	print('Hello World!')

