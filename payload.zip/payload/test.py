def test_fn(arg=None):
	return arg

